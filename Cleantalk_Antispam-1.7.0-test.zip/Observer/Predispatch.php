<?php

namespace Cleantalk\Antispam\Observer;

use Cleantalk\Common\Antispam\Cleantalk;
use Cleantalk\Common\Antispam\CleantalkRequest;
use Cleantalk\Common\Helper\Helper;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;


class Predispatch implements ObserverInterface
{
    protected $_cookieManager;

    protected $scopeConfig;

    protected $config_writer;

    /**
     * @var \Magento\Framework\App\ActionFlag
     */
    private $_actionFlag;

    /**
     * @var \Laminas\Stdlib\ParametersInterface|mixed
     */
    private $_post;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\App\Config\Storage\WriterInterface $configWriter,
        \Magento\Framework\App\ActionFlag $actionFlag
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_cookieManager = $cookieManager;
        $this->config_writer = $configWriter;
        $this->_actionFlag = $actionFlag;
    }

    // * Get a configuration value
    public function getConfigValue($settings)
    {
        return $this->scopeConfig->getValue(
            'general/cleantalkantispam/' . $settings,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    //Get cookie
    public function getCookie($cookie_name)
    {
        $result = $this->_cookieManager->getCookie($cookie_name, 'default value');
        return $result;
    }

    public function execute(Observer $observer)
    {
        //Go out if CleanTalk disabled
        if ( !$this->getConfigValue('ct_enabled') ) {
            return;
        }

        $controller = $observer->getControllerAction();
        if (!method_exists($controller, 'getRequest')) {
            return;
        }

        $request = $controller->getRequest();
        $requestUri = (string)$request->getRequestUri();
        $this->_post = $request->getPostValue();

        if (
            strpos($requestUri, '/ajaxcart/') !== false ||
            strpos($requestUri, 'sagepay') !== false ||
            strpos($requestUri, 'paypal') !== false ||
            strpos($requestUri, 'customer/address/edit') !== false ||
            strpos($requestUri, 'customer/account/createpassword') !== false ||
            strpos($requestUri, 'customer/address/new') !== false ||
            (isset($this->_post['action_url']) && strpos($this->_post['action_url'], 'checkout/cart/add') !== false) ||
            strpos($requestUri, 'wishlist/index/add') !== false ||
            strpos($requestUri, 'instagrampro/gallery/instalist') !== false ||
            (isset($this->_post['customerEmail']) && strpos($requestUri, 'isEmailAvailable') !== false)
        ) {
            return;
        }
        // Cookie values are planted from cleantalk.js. A Set-Cookie header on a
        // cacheable GET response makes Varnish skip the page, so the marketplace
        // page-cache test never sees HIT.
        //Exeptions for spam protection
        if ( isset($this->_post) && count($this->_post) ) {
            //Flag to disable custom contact form checking
            $ct_already_checked = false;

            //Registrations
            $registration_test_enabled = $this->getConfigValue('ct_registrations');
            if (
                $registration_test_enabled &&
                (
                    (
                        strpos($_SERVER['REQUEST_URI'], 'account/createpost') !== false &&
                        isset($this->_post['firstname'], $this->_post['lastname'], $this->_post['email'])
                    ) ||
                    (
                        strpos($_SERVER['REQUEST_URI'], 'account/create') !== false &&
                        isset($this->_post['email'], $this->_post['password'], $this->_post['confirmation'])
                    )
                )
            ) {
                $ct_fields = $this->cleantalkGetFields($this->_post);
                $result_array = $this->setArrayToSend($ct_fields, 'register');

                $ct_already_checked = true;
            }

            //Contacts
            $contact_test_enabled = $this->getConfigValue('ct_contact_forms');
            if (
                $contact_test_enabled &&
                strpos($_SERVER['REQUEST_URI'], 'contact/index') !== false &&
                isset($this->_post['name'], $this->_post['email'], $this->_post['telephone'], $this->_post['comment'], $this->_post['hideit'])
            ) {
                $ct_fields = $this->cleantalkGetFields($this->_post);
                $result_array = $this->setArrayToSend($ct_fields, 'feedback_general_contact_form');

                $ct_already_checked = true;
            }
            //Reviews
            $reviews_test_enabled = $this->getConfigValue('ct_reviews');
            if (
                $reviews_test_enabled &&
                strpos($_SERVER['REQUEST_URI'], 'review') !== false &&
                isset($this->_post['nickname'], $this->_post['title'], $this->_post['detail'])
            ) {
                $ct_fields = $this->cleantalkGetFields($this->_post);
                $result_array = $this->setArrayToSend($ct_fields, 'feedback_general_contact_form');

                $ct_already_checked = true;
            }
            //Custom Forms
            $custom_forms_test_enabled = $this->getConfigValue('ct_custom_contact_forms');
            if ( $custom_forms_test_enabled &&
                !$ct_already_checked &&
                strpos($_SERVER['REQUEST_URI'], 'login') === false &&
                strpos($_SERVER['REQUEST_URI'], 'forgotpassword') === false &&
                strpos($_SERVER['REQUEST_URI'], 'account/create') === false &&
                strpos($_SERVER['REQUEST_URI'], 'account/createpost') === false &&
                strpos($_SERVER['REQUEST_URI'], 'account/login') === false &&
                strpos($_SERVER['REQUEST_URI'], 'account/edit') === false
            ) {
                $ct_fields = $this->cleantalkGetFields($this->_post);
                $result_array = $this->setArrayToSend($ct_fields, 'feedback_general_contact_form');
            }

            //Rrequest and block if needed
            if ( isset($result_array) ) {
                $aResult = $this->CheckSpam($result_array);
                if ( isset($aResult) && is_array($aResult) ) {
                    if ( $aResult['errno'] == 0 ) {
                        if ( $aResult['allow'] == 0 ) {
                            $response = $observer->getControllerAction()->getResponse();
                            $this->_actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
                            return $response->setBody($this->CleantalkDie($aResult['ct_result_comment']));
                        }
                    }
                }
            }
        }
    }

    //Prepares data to request
    private function setArrayToSend($arr, $type)
    {
        $result_array = array();
        $result_array['type'] = $type;
        $result_array['sender_email'] = ($arr['email'] ? $arr['email'] : '');
        $result_array['sender_nickname'] = ($arr['nickname'] ? $arr['nickname'] : '');
        $result_array['message_title'] = '';
        $result_array['message_body'] = ($arr['message'] ? $arr['message'] : '');
        $result_array['example_title'] = '';
        $result_array['example_body'] = '';
        $result_array['example_comments'] = '';
        $result_array['send_request'] = ($arr['message'] || $arr['email']) ? true : false;
        return $result_array;
    }

    /**
     * Checks cookies planted by cleantalk.js.
     *
     * The hash prefix is sha256(access key), the same value already passed to the
     * browser as jsKey. A previous package hashed the raw access key in PHP.
     *
     * @return int|null
     */
    private function cookies_test()
    {
        if ( !isset($_COOKIE['ct_cookies_test']) ) {
            return null;
        }

        $cookie_test = json_decode(stripslashes($_COOKIE['ct_cookies_test']), true);
        if ( !is_array($cookie_test) || empty($cookie_test['cookies_names']) || !is_array($cookie_test['cookies_names']) ) {
            return 0;
        }

        $cookie_values = '';
        foreach ( $cookie_test['cookies_names'] as $cookie_name ) {
            $cookie_values .= isset($_COOKIE[$cookie_name]) ? $_COOKIE[$cookie_name] : '';
        }

        $access_key = (string)$this->getConfigValue('ct_access_key');
        $check_value = isset($cookie_test['check_value']) ? (string)$cookie_test['check_value'] : '';
        $expected_from_js = hash('sha256', hash('sha256', $access_key) . $cookie_values);
        $expected_from_php = hash('sha256', $access_key . $cookie_values);

        if ( hash_equals($expected_from_js, $check_value) || hash_equals($expected_from_php, $check_value) ) {
            return 1;
        }

        return 0;
    }

    //Recursevely gets data from array
    private function cleantalkGetFields(
        $arr,
        $message = array(),
        $email = null,
        $nickname = array('nick' => '', 'first' => '', 'last' => ''),
        $subject = null,
        $contact = true,
        $prev_name = ''
    ) {
        //Skip request if fields exists
        $skip_params = array(
            'ipn_track_id',     // PayPal IPN #
            'txn_type',         // PayPal transaction type
            'payment_status',   // PayPal payment status
            'ccbill_ipn',       // CCBill IPN
            'ct_checkjs',       // skip ct_checkjs field
            'api_mode',         // DigiStore-API
            'loadLastCommentId' // Plugin: WP Discuz. ticket_id=5571
        );

        // Fields to replace with ****
        $obfuscate_params = array(
            'password',
            'password_confirmation',
            'pass',
            'pwd',
            'pswd'
        );

        // Skip feilds with these strings and known service fields
        $skip_fields_with_strings = array(
            // Common
            'ct_checkjs', //Do not send ct_checkjs
            'nonce', //nonce for strings such as 'rsvp_nonce_name'
            'security',
            // 'action',
            'http_referer',
            'timestamp',
            'captcha',
            // Formidable Form
            'form_key',
            'submit_entry',
            // Custom Contact Forms
            'form_id',
            'ccf_form',
            'form_page',
            // Qu Forms
            'iphorm_uid',
            'form_url',
            'post_id',
            'iphorm_ajax',
            'iphorm_id',
            // Fast SecureContact Froms
            'fs_postonce_1',
            'fscf_submitted',
            'mailto_id',
            'si_contact_action',
            // Ninja Forms
            'formData_id',
            'formData_settings',
            'formData_fields_\d+_id',
            'formData_fields_\d+_files.*',
            // E_signature
            'recipient_signature',
            'output_\d+_\w{0,2}',
            // Contact Form by Web-Settler protection
            '_formId',
            '_returnLink',
            // Social login and more
            '_save',
            '_facebook',
            '_social',
            'user_login-',
            'submit',
            'form_token',
            'creation_time',
            'uenc',
            'product',
            'qty',

        );

        foreach ( $skip_params as $value ) {
            if ( array_key_exists($value, $this->_post) ) {
                $contact = false;
            }
        }
        unset($value);

        if ( count($arr) ) {
            foreach ( $arr as $key => $value ) {
                if ( gettype($value) == 'string' ) {
                    $decoded_json_value = json_decode($value, true);
                    if ( $decoded_json_value !== null ) {
                        $value = $decoded_json_value;
                    }
                }

                if ( !is_array($value) && !is_object($value) ) {
                    if ( in_array($key, $skip_params, true) && $key != 0 && $key != '' || preg_match(
                            "/^ct_checkjs/",
                            $key
                        ) ) {
                        $contact = false;
                    }

                    if ( $value === '' ) {
                        continue;
                    }

                    // Skipping fields names with strings from (array)skip_fields_with_strings
                    foreach ( $skip_fields_with_strings as $needle ) {
                        if ( preg_match("/" . $needle . "/", $prev_name . $key) == 1 ) {
                            continue(2);
                        }
                    }
                    unset($needle);
                    // Obfuscating params
                    foreach ( $obfuscate_params as $needle ) {
                        if ( strpos($key, $needle) !== false ) {
                            $value = self::obfuscate_param($value);
                        }
                    }
                    unset($needle);

                    // Removes whitespaces
                    $value = urldecode(trim($value)); // Fully cleaned message
                    $value_for_email = trim(
                        $value
                    );    // Removes shortcodes to do better spam filtration on server side.

                    // Email
                    if ( !$email && preg_match("/^\S+@\S+\.\S+$/", $value_for_email) ) {
                        $email = $value_for_email;
                        // Names
                    } elseif ( preg_match("/name/i", $key) ) {
                        preg_match("/(first.?name)?(name.?first)?(forename)?/", $key, $match_forename);
                        preg_match("/(last.?name)?(family.?name)?(second.?name)?(surname)?/", $key, $match_surname);
                        preg_match("/(nick.?name)?(user.?name)?(nick)?/", $key, $match_nickname);

                        if ( count($match_forename) > 1 ) {
                            $nickname['first'] = $value;
                        } elseif ( count($match_surname) > 1 ) {
                            $nickname['last'] = $value;
                        } elseif ( count($match_nickname) > 1 ) {
                            $nickname['nick'] = $value;
                        } else {
                            $message[$prev_name . $key] = $value;
                        }
                        // Subject
                    } elseif ( $subject === null && preg_match("/subject/i", $key) ) {
                        $subject = $value;
                        // Message
                    } else {
                        $message[$prev_name . $key] = $value;
                    }
                } elseif ( !is_object($value) ) {
                    $prev_name_original = $prev_name;
                    $prev_name = ($prev_name === '' ? $key . '_' : $prev_name . $key . '_');

                    $temp = self::cleantalkGetFields(
                        $value,
                        $message,
                        $email,
                        $nickname,
                        $subject,
                        $contact,
                        $prev_name
                    );

                    $message = $temp['message'];
                    $email = ($temp['email'] ? $temp['email'] : null);
                    $nickname = ($temp['nickname'] ? $temp['nickname'] : null);
                    $subject = ($temp['subject'] ? $temp['subject'] : null);
                    if ( $contact === true ) {
                        $contact = ($temp['contact'] === false ? false : true);
                    }
                    $prev_name = $prev_name_original;
                }
            }
            unset($key, $value);
        }

        //If top iteration, returns compiled name field. Example: "Nickname Firtsname Lastname".
        if ( $prev_name === '' ) {
            if ( !empty($nickname) ) {
                $nickname_str = '';
                foreach ( $nickname as $value ) {
                    $nickname_str .= ($value ? $value . " " : "");
                }
                unset($value);
            }
            $nickname = $nickname_str;
        }

        $return_param = array(
            'email' => $email,
            'nickname' => $nickname,
            'subject' => $subject,
            'contact' => $contact,
            'message' => $message
        );
        return $return_param;
    }

    /**
     * Masks a value with asterisks (*)
     * @return string
     */
    private function obfuscate_param($value = null)
    {
        if ( $value && (!is_object($value) || !is_array($value)) ) {
            $length = strlen($value);
            $value = str_repeat('*', $length);
        }
        return $value;
    }

    /**
     * Die function - Get HTML for the die page
     *
     * @param $message
     * @return string
     */
    private function CleantalkDie($message)
    {
        $error_tpl = file_get_contents(dirname(__FILE__) . "/error.html");
        return str_replace('%ERROR_TEXT%', $message, $error_tpl);
    }

    /**
     * Universal method for checking comment or new user for spam
     * It makes checking itself
     * @param &array Entity to check (comment or new user)
     * @param boolean Notify admin about errors by email or not (default FALSE)
     * @return array|null Checking result or NULL when bad params
     */
    private function CheckSpam($arEntity)
    {
        if ( !is_array($arEntity) || !array_key_exists('type', $arEntity) || $arEntity['send_request'] === false ) {
            return;
        }
        $url_exclusions_config = $this->getConfigValue('ct_exclude_urls');
        if ( !empty($url_exclusions_config) && !is_null($url_exclusions_config) ) {
            $get_exclusions = explode(',', trim($url_exclusions_config));
            if ( $get_exclusions && is_array($get_exclusions) && count($get_exclusions) > 0 ) {
                foreach ( $get_exclusions as $key => $value ) {
                    if ( strpos($_SERVER['REQUEST_URI'], $value) !== false ) { // Simple string checking
                        return;
                    }
                }
            }
        }
        $type = $arEntity['type'];
        if ( $type != 'feedback_general_contact_form' && $type != 'register' ) {
            return;
        }

        $ct_key = $this->getConfigValue('ct_access_key');

        $ct_ws = array(
            'work_url' => 'https://moderate.cleantalk.org',
            'server_url' => 'https://moderate.cleantalk.org',
            'server_ttl' => 0,
            'server_changed' => 0,
        );
        $checkjs = $this->getCookie('ct_checkjs') == hash('sha256', (string)$this->getConfigValue('ct_access_key')) ? 1 : 0;
        $timezone = $this->getCookie('ct_timezone');
        $ref_pref = $this->getCookie('ct_prev_referer');
        $fkp_timestamp = $this->getCookie('ct_fkp_timestamp');
        $pointer_data = $this->getCookie('ct_pointer_data');
        $ps_timestamp = $this->getCookie('ct_ps_timestamp');
        $ct_timestamp = $this->getCookie('ct_timestamp');
        if ( isset($_SERVER['HTTP_USER_AGENT']) ) {
            $user_agent = htmlspecialchars((string)$_SERVER['HTTP_USER_AGENT']);
        } else {
            $user_agent = null;
        }

        if ( isset($_SERVER['HTTP_REFERER']) ) {
            $refferrer = htmlspecialchars((string)$_SERVER['HTTP_REFERER']);
        } else {
            $refferrer = null;
        }

        $ct_language = 'en';

        $sender_info = array(
            'cms_lang' => $ct_language,
            'REFFERRER' => $refferrer,
            'post_url' => $refferrer,
            'USER_AGENT' => $user_agent,
            'js_timezone' => ($timezone && $timezone !== 'default value') ? $timezone : '',
            'REFFERRER_PREVIOUS' => ($ref_pref && $ref_pref !== 'default value') ? $ref_pref : null,
            'cookies_enabled' => $this->cookies_test(),
            'mouse_cursor_positions' => ($pointer_data) ? json_decode($pointer_data) : '',
            'key_press_timestamp' => ($fkp_timestamp && $fkp_timestamp !== 'default value') ? $fkp_timestamp : 0,
            'page_set_timestamp' => ($ps_timestamp && $ps_timestamp !== 'default value') ? $ps_timestamp : 0,
        );
        $sender_info = json_encode($sender_info);

        $ct = new Cleantalk();
        $ct->work_url = $ct_ws['work_url'];
        $ct->server_url = $ct_ws['server_url'];
        $ct->server_ttl = $ct_ws['server_ttl'];
        $ct->server_changed = $ct_ws['server_changed'];

        $sender_ip = Helper::ipGet('remote_addr', false);
        $ct_request = new CleantalkRequest();
        $ct_request->auth_key = $ct_key;
        $ct_request->sender_email = isset($arEntity['sender_email']) ? $arEntity['sender_email'] : '';
        $ct_request->sender_nickname = isset($arEntity['sender_nickname']) ? $arEntity['sender_nickname'] : '';
        $ct_request->sender_ip = isset($arEntity['sender_ip']) ? $arEntity['sender_ip'] : $sender_ip;
        $ct_request->agent = 'magento2-1.7.0';
        $ct_request->js_on = $checkjs;
        $ct_request->sender_info = $sender_info;
        $ct_request->submit_time = ($ct_timestamp) ? time() - intval($ct_timestamp) : 0;

        switch ( $type ) {
            case 'feedback_general_contact_form':
                // Skip submission if no data found
                if ( $ct_request->sender_email === '' && $ct_request->sender_nickname === '' ) {
                    return false;
                }
                $timelabels_key = 'mail_error_comment';
                if ( isset($arEntity['message_title']) ) {
                    $message_title = is_array($arEntity['message_title']) ? implode(
                        " ",
                        $arEntity['message_title']
                    ) : $arEntity['message_title'];
                } else {
                    $message_title = '';
                }
                if ( isset($arEntity['message_body']) ) {
                    $message_body = is_array($arEntity['message_body']) ? implode(
                        " ",
                        $arEntity['message_body']
                    ) : $arEntity['message_body'];
                } else {
                    $message_body = '';
                }
                $ct_request->message = $message_title . " \n\n" . $message_body;

                $example = '';
                $a_example['title'] = isset($arEntity['example_title']) ? $arEntity['example_title'] : '';
                $a_example['body'] = isset($arEntity['example_body']) ? $arEntity['example_body'] : '';
                $a_example['comments'] = isset($arEntity['example_comments']) ? $arEntity['example_comments'] : '';

                // Additional info.
                $post_info = '';
                $a_post_info['comment_type'] = 'feedback_general_contact_form';

                // JSON format.
                $example = json_encode($a_example);
                $post_info = json_encode($a_post_info);

                // Plain text format.
                if ( $example === false ) {
                    $example = '';
                    $example .= $a_example['title'] . " \n\n";
                    $example .= $a_example['body'] . " \n\n";
                    $example .= $a_example['comments'];
                }
                if ( $post_info === false ) {
                    $post_info = '';
                }

                // Example text + last N comments in json or plain text format.
                $ct_request->example = $example;
                $ct_request->post_info = $post_info;
                $ct_result = $ct->isAllowMessage($ct_request);
                break;
            case 'register':
                $timelabels_key = 'mail_error_reg';
                $ct_request->tz = isset($arEntity['user_timezone']) ? $arEntity['user_timezone'] : null;
                $ct_result = $ct->isAllowUser($ct_request);
        }
        $ret_val = array();
        $ret_val['ct_request_id'] = $ct_result->id;

        // First check errstr flag.
        if ( !empty($ct_result->errstr)
            || (!empty($ct_result->inactive) && $ct_result->inactive == 1)
        ) {
            // Cleantalk error so we go default way (no action at all).
            $ret_val['errno'] = 1;
            $err_title = $_SERVER['SERVER_NAME'] . ' - CleanTalk module error';

            if ( !empty($ct_result->errstr) ) {
                if ( preg_match('//u', $ct_result->errstr) ) {
                    $err_str = preg_replace('/^[^\*]*?\*\*\*|\*\*\*[^\*]*?$/iu', '', $ct_result->errstr);
                } else {
                    $err_str = preg_replace('/^[^\*]*?\*\*\*|\*\*\*[^\*]*?$/i', '', $ct_result->errstr);
                }
            } else {
                if ( preg_match('//u', $ct_result->comment) ) {
                    $err_str = preg_replace('/^[^\*]*?\*\*\*|\*\*\*[^\*]*?$/iu', '', $ct_result->comment);
                } else {
                    $err_str = preg_replace('/^[^\*]*?\*\*\*|\*\*\*[^\*]*?$/i', '', $ct_result->comment);
                }
            }
            $ret_val['errstr'] = $err_str;

            return $ret_val;
        }
        $ret_val['errno'] = 0;
        if ( $ct_result->allow == 1 ) {
            // Not spammer.
            $ret_val['allow'] = 1;
        } else {
            $ret_val['allow'] = 0;
            $ret_val['ct_result_comment'] = $ct_result->comment;
            // Spammer.
            // Check stop_queue flag.
            if ( $type == 'comment' && $ct_result->stop_queue == 0 ) {
                // Spammer and stop_queue == 0 - to manual approvement.
                $ret_val['stop_queue'] = 0;
            } else {
                // New user or Spammer and stop_queue == 1 - display message and exit.
                $ret_val['stop_queue'] = 1;
            }
        }
        return $ret_val;
    }
}
